from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.decorators import action
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListCreateAPIView

from .models import (
    Blog,
    Event, EventRegistration,
    Program, ProjectName, Project,
    SheCan
    )
from .serializers import (
    BlogSerializer,
    EventSerializer, EventRegistrationSerializer,
    ProgramSerializer, ProjectNameSerializer, ProjectSerializer,
    SheCanSerializer
    )
from rest_framework import generics, viewsets

class BlogListAPIView(viewsets.ModelViewSet):
    queryset = Blog.objects.all().order_by('-created_at')
    serializer_class = BlogSerializer

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.filter(is_active=True)
    serializer_class = EventSerializer

class EventRegistrationView(generics.CreateAPIView):
    serializer_class = EventRegistrationSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Registration Successful"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
@api_view(['GET'])
def event_details_with_registrations(request, event_id):
    event = Event.objects.get(id=event_id)
    registered_users = EventRegistration.objects.filter(event=event)
    
    event_data = EventSerializer(event).data
    event_data["registered_users"] = [
        {"name": user.name, "email": user.email} for user in registered_users
    ]
    
    return Response(event_data)

class ProgramViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Program.objects.all()
    serializer_class = ProgramSerializer

class ProjectViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = ProjectName.objects.all()
    serializer_class = ProjectNameSerializer

class ProjectDetailViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer

class SheCanAPIView(viewsets.ModelViewSet):
    queryset = SheCan.objects.all()
    serializer_class = SheCanSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        name = self.request.query_params.get('name', None)
        if name:
            queryset = queryset.filter(full_name__icontains=name)
        return queryset
