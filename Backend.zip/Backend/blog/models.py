from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
from django.utils import timezone

class Blog(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    image = models.ImageField(upload_to='blog_images/')
    date = models.DateField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
    
################### Events Page #################

class Sponsor(models.Model):
    name = models.CharField(max_length=100)
    logo = models.ImageField(upload_to="sponsor_logos/")

    def __str__(self):
        return self.name

class InvitedGuest(models.Model):
    name = models.CharField(max_length=100)
    photo = models.ImageField(upload_to="guest_photos/")

    def __str__(self):
        return self.name

class Event(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    venue = models.CharField(max_length=200)
    date = models.DateField()
    time = models.TimeField()
    sponsors = models.ManyToManyField(Sponsor, blank=True, related_name="events")
    invited_guests = models.ManyToManyField(InvitedGuest,  blank=True, related_name="events")
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.title
    
class EventImage(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="images")
    image = models.ImageField(upload_to="event_images/")

    def __str__(self):
        return f"Image for {self.event.title}"
    
class EventRegistration(models.Model):
    event = models.ForeignKey(Event, on_delete=models.PROTECT, null=True, related_name="registrations")
    name = models.CharField(max_length=100)
    email = models.EmailField()

    def __str__(self):
        return f"{self.name} - {self.event.title}"
    
################### Events Page #################

############# Program and Project ###############

class Program(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.name
    
class ProjectName(models.Model):
    program = models.ForeignKey(Program, on_delete=models.CASCADE, related_name="project_names")
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name


class Project(models.Model):
    program = models.ForeignKey(ProjectName, on_delete=models.CASCADE, related_name="projects")
    title = models.CharField(max_length=255)
    description = models.TextField()
    image = models.ImageField(upload_to="project_images/")
    video = models.FileField(upload_to="project_videos/", blank=True, null=True)
    total_budget = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class ProjectItem(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="items")
    name = models.CharField(max_length=255)
    photo = models.ImageField(upload_to="project_item_photos", blank=True, null=True)
    quantity_needed = models.PositiveIntegerField(blank=True, null=True)
    funds_needed = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)

    def __str__(self):
        return f"{self.name} for {self.project.title}"

class Donor(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)  # blank name for anonymous donations
    is_anonymous = models.BooleanField(default=False)
    project_item = models.ForeignKey(ProjectItem, on_delete=models.CASCADE, related_name="donors")
    donation_type = models.CharField(max_length=10, choices=[("cash", "Cash"), ("inkind", "In-Kind")])
    amount_donated = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    quantity_donated = models.PositiveIntegerField(blank=True, null=True)
    donation_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        donor_name = "Anonymous" if self.is_anonymous else self.name
        return f"{donor_name} donated to {self.project_item.name}"
    
############# Program and Project ###############

################ Profile Infos start ############################ 

class SheCan(models.Model):
    full_name = models.CharField(max_length=100)
    shecan_id = models.CharField(max_length=50, unique=True)
    profession = models.CharField(max_length=300, default="Undefined")
    self_description = models.TextField(blank=True, null=True)
    phone = PhoneNumberField(blank=True, null=True, help_text="+251912345678")
    address = models.CharField(max_length=255, blank=True, null=True)
    picture = models.ImageField(upload_to="shecan_images/")
    email = models.EmailField(max_length=254, blank=True, null=True)
    telegram = models.CharField(max_length=150, blank=True, null=True)
    instagram = models.CharField(max_length=150, blank=True, null=True)
    linkedin = models.CharField(max_length=150, blank=True, null=True)
    facebook = models.CharField(max_length=150, blank=True, null=True)
    skype = models.CharField(max_length=255, blank=True, null=True)

    skills = models.ManyToManyField("Skill", blank=True)
    languages = models.ManyToManyField("Language", blank=True)
    certificates = models.ManyToManyField("Certificate", blank=True)
    honors_and_awards = models.ManyToManyField("HonorAndAward", blank=True)
    interests = models.ManyToManyField("Interest", blank=True)
    work_experience = models.ManyToManyField("WorkExperience", blank=True)
    education = models.ManyToManyField("Education", blank=True)

    def __str__(self):
        return self.full_name
    
class Skill(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Language(models.Model):
    name = models.CharField(max_length=100)
    proficiency = models.CharField(max_length=50, choices=[
        ('Native', 'Native'),
        ('Fluent', 'Fluent'),
        ('Intermediate', 'Intermediate'),
        ('Beginner', 'Beginner')
    ])

    def __str__(self):
        return f"{self.name} ({self.proficiency})"

class Certificate(models.Model):
    title = models.CharField(max_length=255)
    organization = models.CharField(max_length=255)
    date_awarded = models.DateField()

    def __str__(self):
        return f"{self.title} - {self.organization} ({self.date_awarded})"

class HonorAndAward(models.Model):
    title = models.CharField(max_length=255)
    organization = models.CharField(max_length=255)
    date_awarded = models.DateField()

    def __str__(self):
        return f"{self.title} - {self.organization} ({self.date_awarded})"

class Interest(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class WorkExperience(models.Model):
    job_title = models.CharField(max_length=255)
    company = models.CharField(max_length=255)
    start_date = models.DateField()
    end_date = models.DateField(blank=True, null=True)
    location = models.CharField(max_length=255, blank=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.job_title} at {self.company} ({self.start_date} - {self.end_date or 'Present'})"

class Education(models.Model):
    degree = models.CharField(max_length=255)
    institution = models.CharField(max_length=255)
    start_date = models.DateField()
    graduation_date = models.DateField(blank=True, null=True)
    location = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.degree} at {self.institution} ({self.start_date} - {self.graduation_date or 'Present'})"

################ Profile infos end ############################ 

