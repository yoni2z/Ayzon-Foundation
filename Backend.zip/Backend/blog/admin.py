from django.contrib import admin

from .models import (
    Blog,
    Sponsor, 
    InvitedGuest, 
    Event, EventImage, 
    EventRegistration,
    Program, ProjectName, Project, ProjectItem, Donor,
    SheCan, Skill, Language, Certificate, HonorAndAward, Interest, WorkExperience, Education, 
)
# Register your models here.

admin.site.register(Blog)
admin.site.register(Sponsor)
admin.site.register(InvitedGuest)
admin.site.register(Event)
admin.site.register(EventImage)
admin.site.register(EventRegistration)
admin.site.register(Program)
admin.site.register(ProjectName)
admin.site.register(Project)
admin.site.register(ProjectItem)
admin.site.register(Donor)
admin.site.register(SheCan)
admin.site.register(Skill)
admin.site.register(Language)
admin.site.register(Certificate)
admin.site.register(HonorAndAward)
admin.site.register(Interest)
admin.site.register(WorkExperience)
admin.site.register(Education)


