from django.urls import path, include
from rest_framework.routers import DefaultRouter
from django.conf import settings
from django.conf.urls.static import static
from .views import (
    BlogListAPIView,
    EventViewSet,
    EventRegistrationView,
    event_details_with_registrations,
     ProgramViewSet,
    ProjectViewSet,
    ProjectDetailViewSet,
    SheCanAPIView
    )

router = DefaultRouter()
router.register(r'programs', ProgramViewSet)
router.register(r'projects', ProjectViewSet, basename='project')
router.register(r'project-details', ProjectDetailViewSet, basename='project-detail')

urlpatterns = [
    path('api/blogs/', BlogListAPIView.as_view({'get': 'list'}), name='blog_list'),
    path('api/blogs/<int:pk>/', BlogListAPIView.as_view({'get': 'retrieve'}), name='blog-details'),
    path('api/events/', EventViewSet.as_view({'get': 'list'}), name='event-list'),
    path('api/events/<int:pk>/', EventViewSet.as_view({'get': 'retrieve'}), name='event-detail'),
    path('api/events/register/', EventRegistrationView.as_view(), name='event-registration'),
    path('api/events/registered/<int:event_id>/', event_details_with_registrations, name='event-details-with-registrations'),
    path('api/shecan/', SheCanAPIView.as_view({'get': 'list'}), name = "she-can"),
    path('api/shecan/<int:pk>/', SheCanAPIView.as_view({'get': 'retrieve'}), name = "she-can-details"),
    path('api/', include(router.urls)),
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)